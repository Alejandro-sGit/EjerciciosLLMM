function writed(){
	document.getElementById("demo").innerHTML= "Hello World!"
}
