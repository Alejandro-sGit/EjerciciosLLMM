
function myFunction(){
	document.getElementById("demo").innerHTML= "paragraph changed."
}
function clear_paragraph(){
	document.getElementById("demo").style.display="none";
}

